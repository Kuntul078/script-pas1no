<?php

#USERAGENT
$useragent = "xxxxxx";

#COOKIE_DASHBOARD
$cookie = 'xxxxxx';

